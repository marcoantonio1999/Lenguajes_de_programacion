module Sintax where
	
type Identifier = String
data Expr = V Identifier | I Int | B Bool
			| Add Expr Expr | Mul Expr Expr | Succ Expr
			| Pred Expr
			| Not Expr | And Expr Expr | Or Expr Expr
			| Lt Expr Expr | Gt Expr Expr | Eq Expr Expr
			| If Expr Expr Expr
			| Let Identifier Expr Expr 
			deriving (Eq)

instance Show Expr where 
	show	(V x )      = " V    [" ++    x ++             "] "
	show	(I n )      = " N    [" ++ (show n) ++         "] "
	show	(B b )      = " B    [" ++ (show b) ++         "] "
	show	(Add a b)   = "ADD   ["++ (show a) ++","++ (show b) ++"]"
	show	(Mul a b)   = "MUL   ["++ (show a) ++","++ (show b) ++"]"
	show	(Eq a b)    = "Eq    ["++ (show a) ++","++ (show b) ++"]"
	show	(And a b)   = "And   ["++ (show a) ++","++ (show b) ++"]"
	show	(Or  a b)   = "Or    ["++ (show a) ++","++ (show b) ++"]"
	show	(Gt a b)    = "Gt    ["++ (show a) ++","++ (show b) ++"]"
	show	(Lt a b)    = "MUL   ["++ (show a) ++","++ (show b) ++"]"
	show	(Not a)	    = "Not   ["++ (show a) ++          "]" 
	show	(If a b c)  = "If    ["++ (show a) ++","++ (show b) ++","++ (show c) ++ "]"
	show	(Let x a b) = "Let   ["++     x    ++","++ (show a) ++","++ (show b) ++ "]"
	show	(Succ a)    = "Succ  ["++ (show a) ++  "]"
	show	(Pred a)    = "Pred  ["++ (show a)  ++ "]"
			



type Substitution = ( Identifier , Expr )	

{-quita los identificadores en una lista de identificadores-}

rm :: Identifier -> [Identifier] -> [Identifier]
rm _ [] = []
rm a (x:xs) 
    | a == x = xs
    | otherwise = x:(rm a xs) 

{-Obtiene el conjunto de variables libres de una ex-
presión.-}

frVars :: Expr -> [Identifier]
frVars a = case a of
    (V x) -> [x]
    (I n) -> []
    (B b) -> []
    (Add a b ) -> (frVars a) ++ (frVars b)
    (Mul a b ) -> (frVars a) ++ (frVars b)
    (Succ b ) -> (frVars b) 
    (Pred p ) -> (frVars p)
    (Not p ) -> (frVars p)
    (And p q ) -> (frVars p) ++ (frVars q)
    (Or p q ) -> (frVars p) ++ (frVars q)
    (Lt p q ) -> (frVars p) ++ (frVars q)
    (Gt p q) -> (frVars p) ++ (frVars q)
    (Eq p q) -> (frVars p) ++ (frVars q)
    (If a b c) -> (frVars a) ++ (frVars b) ++ (frVars c)
    (Let a b c) -> (frVars b) ++ (rm a (frVars c))

{-Aplica la sustitución a la expresión dada en caso de ser
posible.-}

subst :: Expr -> Substitution -> Expr
subst a (y,z) = case a of 
    (V x) -> if x == y then z else (V x)
    (I n) -> a
    (B b) -> a
    (Add a b ) -> Add (subst a (y,z)) (subst b (y,z))
    (Mul a b ) -> Mul (subst a (y,z)) (subst b (y,z))
    (Succ b ) -> Succ (subst b (y,z)) 
    (Pred p ) -> Pred (subst p (y,z)) 
    (Not p ) -> Not (subst a (y,z)) 
    (And p q ) -> And (subst p (y,z)) (subst q (y,z))
    (Or p q ) -> Or (subst p (y,z)) (subst q (y,z))
    (Lt p q ) -> Lt (subst p (y,z)) (subst q (y,z))
    (Gt p q) -> Gt (subst p (y,z)) (subst q (y,z))
    (Eq p q) -> Eq (subst p (y,z)) (subst q (y,z))
    (If a b c) -> If (subst a (y,z)) (subst b (y,z)) (subst c (y,z)) 
    (Let a b c) -> if a == y ||  (elem a (frVars c))
        then error "No se puede aplicar la Sustitucion." 
        else (if (elem a (frVars z)) then error "Se ligan variables libres." else Let a (subst b (y,z)) (subst c (y,z)))
{-Aplica Alpha-Equivalencia-}

alphaEq :: Expr -> Expr -> Bool
alphaEq (V a) (V b)         = a==b
alphaEq (B a) (B b)         = a==b
alphaEq (I i) (I k)         = i==k  
alphaEq (Add a b) (Add c d) = (alphaEq a c) && (alphaEq b d)   	
alphaEq (Mul a b) (Mul c d) = (alphaEq a c) && (alphaEq b d)
alphaEq (And a b) (And c d) = (alphaEq a c) && (alphaEq b d)   	
alphaEq (Or  a b) (Or c d)  = (alphaEq a c) && (alphaEq b d)   	
alphaEq (Lt  a b) (Lt c d)  = (alphaEq a c) && (alphaEq b d)   	
alphaEq (Gt  a b) (Gt c d)  = (alphaEq a c) && (alphaEq b d)   	
alphaEq (Eq  a b) (Eq c d)  = (alphaEq a c) && (alphaEq b d)   	
alphaEq (Not a)   (Not c ) =  (alphaEq a c)
alphaEq (Succ a)  (Succ c) =  (alphaEq a c)
alphaEq (If a b c)(If d e f) = (alphaEq a d) && (alphaEq b e) && (alphaEq c f)
alphaEq (Let i a b) (Let j c d) = (not (elem i (frVars d))) && (not (elem j (frVars b))) && (alphaEq a c) && (alphaEq b d)



