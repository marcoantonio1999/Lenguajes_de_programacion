module Semantic where
import Sintax
--Borrar hasta importar Sintax
{-
type Identifier = String
data Expr = V Identifier | I Int | B Bool 
    | Add Expr Expr | Mul Expr Expr | Succ Expr
    | Pred Expr
    | Not Expr | And Expr Expr | Or Expr Expr
    | Lt Expr Expr | Gt Expr Expr | Eq Expr Expr
    | If Expr Expr Expr
    | Let Identifier Expr Expr deriving (Eq, Show)

type Substitution = ( Identifier , Expr )

{-Aplica la sustitución a la expresión dada en caso de ser
posible.-}

subst :: Expr -> Substitution -> Expr
subst a (y,z) = case a of 
    (V x) -> if x == y then z else (V x)
    (I n) -> a
    (B b) -> a
    (Add a b ) -> Add (subst a (y,z)) (subst b (y,z))
    (Mul a b ) -> Mul (subst a (y,z)) (subst b (y,z))
    (Succ b ) -> Succ (subst b (y,z)) 
    (Pred p ) -> Pred (subst p (y,z)) 
    (Not p ) -> Not (subst a (y,z)) 
    (And p q ) -> And (subst p (y,z)) (subst q (y,z))
    (Or p q ) -> Or (subst p (y,z)) (subst q (y,z))
    (Lt p q ) -> Lt (subst p (y,z)) (subst q (y,z))
    (Gt p q) -> Gt (subst p (y,z)) (subst q (y,z))
    (Eq p q) -> Eq (subst p (y,z)) (subst q (y,z))
    (If a b c) -> If (subst a (y,z)) (subst b (y,z)) (subst c (y,z)) 
    (Let a b c) -> if a == y ||  (elem a (frVars c))
        then error "No se puede aplicar la Sustitucion." 
        else (if (elem a (frVars z)) then error "Se ligan variables libres." else Let a (subst b (y,z)) (subst c (y,z)))

{-quita los identificadores en una lista de identificadores-}

rm :: Identifier -> [Identifier] -> [Identifier]
rm _ [] = []
rm a (x:xs) 
    | a == x = xs
    | otherwise = x:(rm a xs) 

{-Obtiene el conjunto de variables libres de una ex-
presión.-}

frVars :: Expr -> [Identifier]
frVars a = case a of
    (V x) -> [x]
    (I n) -> []
    (B b) -> []
    (Add a b ) -> (frVars a) ++ (frVars b)
    (Mul a b ) -> (frVars a) ++ (frVars b)
    (Succ b ) -> (frVars b) 
    (Pred p ) -> (frVars p)
    (Not p ) -> (frVars p)
    (And p q ) -> (frVars p) ++ (frVars q)
    (Or p q ) -> (frVars p) ++ (frVars q)
    (Lt p q ) -> (frVars p) ++ (frVars q)
    (Gt p q) -> (frVars p) ++ (frVars q)
    (Eq p q) -> (frVars p) ++ (frVars q)
    (If a b c) -> (frVars a) ++ (frVars b) ++ (frVars c)
    (Let a b c) -> (frVars b) ++ (rm a (frVars c))
-}
--No borrar
{-Devuelve la transición tal que eval1 e = e’ syss e →e0
.-}
eval1 :: Expr -> Expr
eval1 (V x) = (V x)
eval1 (I n) = (I n)
eval1 (B b) = (B b)
eval1 (Add (I n) (I m)) = (I (n+m))
eval1 (Add (I n) b) = (Add (I n) (eval1 b))
eval1 (Add a b) = (Add (eval1 a) b) 
eval1 (Mul (I n) (I m)) = (I (n*m))
eval1 (Mul (I n) b) = (Mul (I n) (eval1 b))
eval1 (Mul a b) = (Mul (eval1 a) b) 
eval1 (Succ (I n)) = (I (n+1))
eval1 (Succ a) = Succ (eval1 a)
eval1 (Pred (I 0)) = (I (0))
eval1 (Pred (I n)) = (I (n-1))
eval1 (Pred a) = (Pred (eval1 a))
eval1 (Not (B b)) = (B (not b))
eval1 (Not b) = (Not (eval1 b))
eval1 (And (B b) (B c)) = (B (b&&c))
eval1 (And (B b) c) = (And (B b) (eval1 c))
eval1 (And b c) = (And (eval1 b) c)
eval1 (Or (B b) (B c)) = (B (b||c))
eval1 (Or (B b) c) = (Or (B b) (eval1 c))
eval1 (Or b c) = (Or (eval1 b) c)
eval1 (Lt (I n) (I m)) = (B (n<m))
eval1 (Lt (I b) c) = (Lt (I b) (eval1 c))
eval1 (Lt b c) = (Lt (eval1 b) c)
eval1 (Gt (I n) (I m)) = (B (n>m))
eval1 (Gt (I b) c) = (Gt (I b) (eval1 c))
eval1 (Gt b c) = (Gt (eval1 b) c)
eval1 (Eq (I n) (I m)) = (B (n==m))
eval1 (Eq (I b) c) = (Eq (I b) (eval1 c))
eval1 (Eq b c) = (Eq (eval1 b) c)
eval1 (If (B b) x y)
    | b = x
    | otherwise = y
eval1 (If b x y) = (If (eval1 b) x y)
eval1 (Let x (I n) c) = (subst c (x,(I n)))
eval1 (Let x (B b) c) = (subst c (x,(B b)))
eval1 (Let x b c) = (Let x (eval1 b) c)

{-Devuelve la transici ́on tal que evals e = e’ syss e →∗e0 y e0 está bloqueado.-}
evals :: Expr -> Expr
evals (V x) = V x
evals (I n) = I n
evals (B b) = B b
evals (Add (I n) (I m)) = (I (n+m))
evals (Add (I n) b) = evals (Add (I n) (evals b))
evals (Add a b) = eval1 (Add (evals a) b) 
evals (Mul (I n) (I m)) = (I (n*m))
evals (Mul (I n) b) = evals (Mul (I n) (evals b))
evals (Mul a b) = eval1 (Mul (evals a) b)
evals (Succ (I n)) = (I (n+1))
evals (Succ a) = eval1 (Succ (evals a))
evals (Pred (I 0)) = (I (0))
evals (Pred (I n)) = (I (n-1))
evals (Pred a) = eval1 (Pred (evals a))
evals (Not (B b)) = (B (not b))
evals (Not b) = eval1 (Not (evals b))
evals (And (B b) (B c)) = (B (b&&c))
evals (And (B b) c) = evals (And (B b) (evals c))
evals (And b c) = eval1 (And (evals b) c)
evals (Or (B b) (B c)) = (B (b||c))
evals (Or (B b) c) = evals (Or (B b) (evals c))
evals (Or b c) = eval1 (Or (evals b) c)
evals (Lt (I n) (I m)) = (B (n<m))
evals (Lt (I b) c) = evals (Lt (I b) (evals c))
evals (Lt b c) = eval1 (Lt (evals b) c)
evals (Gt (I n) (I m)) = (B (n>m))
evals (Gt (I b) c) = evals (Gt (I b) (evals c))
evals (Gt b c) = eval1 (Gt (evals b) c)
evals (Eq (I n) (I m)) = (B (n==m))
evals (Eq (I b) c) = evals (Eq (I b) (evals c))
evals (Eq b c) = eval1 (Eq (evals b) c)
evals (If (B b) x y)
    | b = evals x
    | otherwise = eval1 y
evals (If b x y) = (If (evals b) x y)
evals (Let x (I n) c) = evals (subst c (x,(I n)))
evals (Let x (B b) c) = evals (subst c (x,(B b)))
evals (Let x b c) = evals (Let x (evals b) c)

{-Devuelve la evaluación de un programa tal que evale
e = e’ syss e →∗e0 y e0 es un valor. En caso de que e
0 no esa un valor deberá mostrar un mensaje de error.-}
evale :: Expr -> Expr
evale (Add (B b) _) = error "[Add] Espera dos Numeros."
evale (Add _ (B b)) = error "[Add] Espera dos Numeros."
evale (Mul (B b) _) = error "[Mul] Espera dos Numeros."
evale (Mul _ (B b)) = error "[Mul] Espera dos Numeros."
evale (Succ (B b)) = error "[Succ] Espera un Numero."
evale (Pred (B b)) = error "[Succ] Espera un Numero."
evale (Not (I n)) = error "[Not] Espera un Booleano"
evale (And (I b) _) = error "[And] Espera dos Booleanos."
evale (And _ (I b)) = error "[And] Espera dos Booleanos."
evale (Or (I b) _) = error "[Or] Espera dos Booleanos."
evale (Or _ (I b)) = error "[Or] Espera dos Booleanos."
evale (Lt (B b) _) = error "[Lt] Espera dos Numero."
evale (Lt _ (B b)) = error "[Lt] Espera dos Numero."
evale (Gt (B b) _) = error "[Gt] Espera dos Numero."
evale (Gt _ (B b)) = error "[Gt] Espera dos Numero."
evale (Eq (B b) _) = error "[Eq] Espera dos Numero."
evale (Eq _ (B b)) = error "[Eq] Espera dos Numero."
evale (If (I b) _ _) = error "[If] Espera un Booleano"
evale (V x) = V x
evale (I n) = I n
evale (B b) = B b
evale a = evale (evals a)


data Type = Integer | Boolean deriving (Eq, Show)



type Decl = (Identifier , Type )    
type TypCtxt = [ Decl ]
{-Verifica el tipado de un programa tal que vt Γ e T =
True syss Γ ` e : T.-}

vt :: TypCtxt -> Expr -> Type -> Bool
vt  _ (I _) t     = t == Integer 
vt  _ (B _) t     = t == Boolean
vt  _ (V _) t     = True
vt  [] (Add (I _)(I _)) Boolean = False 
vt  [] (Add a b) t = (vt ([])(a)(Integer)) && (vt ([])(b)(Integer)) 
vt  [] (Mul (I _)(I _)) Boolean = False
vt  [] (Mul a b) t = (vt ([])(a)(Integer)) && (vt ([])(b)(Integer)) 
vt  [] (Succ (I _)) Boolean     = False
vt  [] (Succ a)  t = (vt ([])(a)(Integer)) 
vt  [] (Pred (I _)) Boolean     = False 
vt  [] (Pred a)  t = (vt ([])(a)(Integer))
vt  [] (Not (B _)) Integer      = False 
vt  [] (Not  a)  t = (vt ([])(a)(Boolean)) 
vt  [] (And (B _)(B _)) Integer = False
vt  [] (And a b) t = (vt ([])(a)(Boolean)) && (vt ([])(b)(Boolean))
vt  [] (Or (B _)(B _)) Integer = False
vt  [] (Or a b) t  = (vt ([])(a)(Boolean)) && (vt ([])(b)(Boolean))
vt  [] (Lt (I _)(I _)) Integer = False 
vt  [] (Lt a b) t  = (vt ([])(a)(Integer)) && (vt ([])(b)(Integer))
vt  [] (Gt (I _)(I _)) Integer = False 
vt  [] (Gt a b) t  = (vt ([])(a)(Integer)) && (vt ([])(b)(Integer))
vt  [] (Eq (I _) (I _)) Integer = False
vt  [] (Eq a b) t  = (vt ([])(a)(Integer)) && (vt ([])(b)(Integer))
vt  [] (If (B _)(B _)(B _)) Integer = False
vt  [] (If a b c) t =  (vt ([])(a)(Boolean)) && (vt ([])(b)(Boolean)) && (vt ([])(c)(Boolean))
vt  [] (Let (_)(B _)(B _)) Integer = False
vt  [] (Let (_)(I _)(I _)) Boolean = False
vt  [] (Let a b c) t 
     | (vt ([])(c)(Boolean)) == True && t == Boolean = True
     | (vt ([])(c)(Integer)) == True && t == Integer = True
     | otherwise = (vt ([])(c)(t))
vt  (( x,y):xs) (Succ a) t
     | (elem x (frVars a) == False) = error "La variable no esta definida"
     | (elem x (frVars a) == True) && (y == Integer && t == Integer) = True 
     | (elem x (frVars a) == True) && (t == Boolean) = False
     | (elem x (frVars a) == True) && (y == Boolean) = False
     | otherwise = vt (xs)(Succ a)(t)
vt  (( x,y):xs) (Pred a) t 
     | (elem x (frVars a) == False) = error "La variable no esta definida"
     | (elem x (frVars a) == True) && (y == Integer && t == Integer) = True
     | (elem x (frVars a) == True) && (t == Boolean) = False
     | (elem x (frVars a) == True) && (y == Boolean) = False
     | otherwise = vt (xs)(Pred a)(t)
vt  (( x,y):xs) (Not a) t 
     | (elem x (frVars a) == False) = error "La variable no esta definida"
     | (elem x (frVars a) == True) && (y == Boolean && t == Boolean) = True
     | (elem x (frVars a) == True) && (t == Integer) = False
     | (elem x (frVars a) == True) && (y == Integer) = False
     | otherwise = vt (xs)(Not a)(t)
vt  (( x,y):xs) (Add a b) t 
     | (elem x (frVars a) == True) && (y == Integer && t == Integer) = True && vt (xs)(Add a b)(t)
     | (elem x (frVars a) == True) && (t == Boolean) = False
     | (elem x (frVars a) == True) && (y == Boolean) = False
     | (elem x (frVars b) == True) && (y == Integer && t == Integer) = True && vt (xs)(Add a b)(t)
     | (elem x (frVars b) == True) && (t == Boolean) = False
     | (elem x (frVars b) == True) && (y == Boolean) = False
     | otherwise = vt (xs)(Add a b)(t)
vt  (( x,y):xs) (Mul a b) t 
     | (elem x (frVars a) == True) && (y == Integer && t == Integer) = True && vt (xs)(Mul a b)(t)
     | (elem x (frVars a) == True) && (t == Boolean) = False
     | (elem x (frVars a) == True) && (y == Boolean) = False
     | (elem x (frVars b) == True) && (y == Integer && t == Integer) = True && vt (xs)(Mul a b)(t)
     | (elem x (frVars b) == True) && (t == Boolean) = False
     | (elem x (frVars b) == True) && (y == Boolean) = False
     | otherwise = vt (xs)(Mul a b)(t)
vt  (( x,y):xs) (Or a b) t 
     | (elem x (frVars a) == True) && (y == Boolean && t == Boolean) = True && vt (xs)(Or a b)(t)
     | (elem x (frVars a) == True) && (t == Integer) = False
     | (elem x (frVars a) == True) && (y == Integer) = False
     | (elem x (frVars b) == True) && (y == Boolean && t == Boolean) = True && vt (xs)(Or a b)(t)
     | (elem x (frVars b) == True) && (t == Integer) = False
     | (elem x (frVars b) == True) && (y == Integer) = False
     | otherwise = vt (xs)(Or a b)(t)
vt  (( x,y):xs) (Lt a b) t 
     | (elem x (frVars a) == True) && (y == Integer && t == Boolean) = True && vt (xs)(Lt a b)(t)
     | (elem x (frVars a) == True) && (t == Integer) = False
     | (elem x (frVars a) == True) && (y == Boolean) = False
     | (elem x (frVars b) == True) && (y == Integer && t == Boolean) = True && vt (xs)(Lt a b)(t)
     | (elem x (frVars b) == True) && (t == Integer) = False
     | (elem x (frVars b) == True) && (y == Boolean) = False
     | otherwise = vt (xs)(Lt a b)(t)
vt  (( x,y):xs) (Gt a b) t 
     | (elem x (frVars a) == True) && (y == Integer && t == Boolean) = True && vt (xs)(Gt a b)(t)
     | (elem x (frVars a) == True) && (t == Integer) = False
     | (elem x (frVars a) == True) && (y == Boolean) = False
     | (elem x (frVars b) == True) && (y == Integer && t == Boolean) = True && vt (xs)(Gt a b)(t)
     | (elem x (frVars b) == True) && (t == Integer) = False
     | (elem x (frVars b) == True) && (y == Boolean) = False
     | otherwise = vt (xs)(Gt a b)(t)
vt  (( x,y):xs) (Eq a b) t 
     | (elem x (frVars a) == True) && (y == Integer && t == Boolean) = True && vt (xs)(Eq a b)(t)
     | (elem x (frVars a) == True) && (t == Integer) = False
     | (elem x (frVars a) == True) && (y == Boolean) = False
     | (elem x (frVars b) == True) && (y == Integer && t == Boolean) = True && vt (xs)(Eq a b)(t)
     | (elem x (frVars b) == True) && (t == Integer) = False
     | (elem x (frVars b) == True) && (y == Boolean) = False
     | otherwise = vt (xs)(Eq a b)(t)
vt  (( x,y):xs) (If a b c) t
     | (elem x (frVars a) == True) && (y == Boolean && t == Boolean) = True && vt (xs)(If a b c)(t)
     | (elem x (frVars a) == True) && (t == Integer) = False
     | (elem x (frVars a) == True) && (y == Integer) = False
     | (elem x (frVars b) == True) && (y == Boolean && t == Boolean) = True && vt (xs)(If a b c)(t)
     | (elem x (frVars b) == True) && (t == Integer) = False
     | (elem x (frVars b) == True) && (y == Integer) = False
     | (elem x (frVars c) == True) && (y == Boolean && t == Boolean) = True && vt (xs)(If a b c)(t)
     | (elem x (frVars c) == True) && (t == Integer) = False
     | (elem x (frVars c) == True) && (y == Integer) = False
     | otherwise = vt (xs)(If a b c)(t)
vt  (( x,y):xs) (Let a b c) t
     | (elem x (frVars b) == False)&& (elem x (frVars c) == False) = error "La variable no esta definida"
     | x == a  = error "La variable se repite en las variables ligadas"
     | (elem x (frVars c) == True) && (y == Boolean && t == Boolean) = True && vt (xs)(b)(Boolean)
     | (elem x (frVars c) == True) && (y == Integer && t == Integer) = True && vt (xs)(b)(Integer)
     | (elem x (frVars b) == True) && (y == Boolean && t == Boolean) = True && vt (xs)(c)(Boolean)
     | (elem x (frVars b) == True) && (y == Integer && t == Integer) = True && vt (xs)(b)(Integer)
     | otherwise = vt (xs)(Let a b c)(t)

{-Verifica el tipado de un programa, y en caso de ser
correcto lo eval ́ua hasta obtener un valor.-}

eval :: Expr -> Type -> Expr
eval  a t 
     | ((vt ([])(a)(t))== True) = evale (a) 
     | otherwise = error "el tipado es incorrecto"